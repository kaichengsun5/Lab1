import numpy as np
from ROTX import ROTX
from ROTY import ROTY
from ROTZ import ROTZ

def EULERXYZ(angles):
    
    a, b, c = angles
    return ROTX(a) @ ROTY(b) @ ROTZ(c)
