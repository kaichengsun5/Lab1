import numpy as np
from SKEW3 import SKEW3

def EXPCR(x):
    """
    Compute rotation matrix R = exp([x]_x)
    using Rodrigues' formula.
    Input:
        x : 3x1 vector (rotation vector)
    Output:
        R : 3x3 rotation matrix
    """
    x = np.asarray(x).reshape(3,)
    theta = np.linalg.norm(x)
    I = np.eye(3)

    if theta < 1e-8:
        # Small-angle approximation
        return I + SKEW3(x)
    
    w = x / theta
    W = SKEW3(w)
    R = I + np.sin(theta) * W + (1 - np.cos(theta)) * (W @ W)
    return R
