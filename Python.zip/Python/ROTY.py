import numpy as np

def ROTY(theta):
    """Rotation matrix about Y-axis by theta radians."""
    return np.array([
        [np.cos(theta), 0, np.sin(theta)],
        [0, 1, 0],
        [-np.sin(theta), 0, np.cos(theta)]
    ])
