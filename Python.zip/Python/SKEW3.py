import numpy as np

def SKEW3(x):
    x = np.asarray(x).reshape(3,)
    x1, x2, x3 = x
    S = np.array([[0, -x3, x2],
                  [x3, 0, -x1],
                  [-x2, x1, 0]])
    return S
