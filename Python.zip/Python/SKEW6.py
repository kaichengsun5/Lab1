import numpy as np
from SKEW3 import SKEW3

def SKEW6(xi):
    xi = np.asarray(xi).reshape(6,)
    w = xi[0:3]
    v = xi[3:6]

    W = SKEW3(w)
    Xi = np.zeros((4, 4))
    Xi[0:3, 0:3] = W
    Xi[0:3, 3] = v
    return Xi
