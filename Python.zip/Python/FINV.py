import numpy as np

def FINV(T):
    """
    T = [ R  p ]
        [ 0  1 ]

    Then T_inv = [ R^T  -R^T p ]
                 [ 0      1   ]
    """
    T = np.asarray(T).reshape(4, 4)
    R = T[0:3, 0:3]
    p = T[0:3, 3]

    R_inv = R.T
    p_inv = -R_inv @ p

    T_inv = np.eye(4)
    T_inv[0:3, 0:3] = R_inv
    T_inv[0:3, 3] = p_inv
    return T_inv
