# %%
from EULERXYZ import EULERXYZ
from EULERXYZINV import EULERXYZINV
from EXPCR import EXPCR
from EXPCF import EXPCF
import plots
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('Agg')
from ROTX import ROTX
from ROTY import ROTY
from ROTZ import ROTZ
# %%
# Question 1 and 2
# Rotation functions and names
axes = [("X", ROTX), ("Y", ROTY), ("Z", ROTZ)]
angles = [0, np.pi/6, np.pi/3]  # 0°, 30°, 60°

# (a) Rotation matrices
for name, Rfunc in axes:
    for a in angles:
        R = Rfunc(a)
        plots.plotr(R)
    plt.title(f"(a) Rotation about {name}-axis (0°, 30°, 60°)")
    plt.savefig(f"Q1fig/Q1_a_{name}.png", dpi=300)
    plt.close()

#(b) Rotate points (3×1)
p = np.array([[1], [1], [1]]) 
for name, Rfunc in axes:
    for a in angles:
        R = Rfunc(a)
        p_rot = R @ p
        plots.plotp3(p_rot)
    plt.title(f"(b) Points rotated about {name}-axis (0°, 30°, 60°)")
    plt.savefig(f"Q1fig/Q1_b_{name}.png", dpi=300)
    plt.close()

# (c) Homogeneous points 
p4 = np.array([[1], [1], [1], [1]])
for name, Rfunc in axes:
    for a in angles:
        T = np.eye(4)
        T[:3, :3] = Rfunc(a)
        p4_rot = T @ p4
        plots.plotp4(p4_rot)
    plt.title(f"(c) Homogeneous points rotated about {name}-axis (0°, 30°, 60°)")
    plt.savefig(f"Q1fig/Q1_c_{name}.png", dpi=300)
    plt.close()

# (d) Vectors
p1 = np.zeros((3,1))
p2 = np.array([[1], [1], [1]])
for name, Rfunc in axes:
    for a in angles:
        R = Rfunc(a)
        p1r = R @ p1
        p2r = R @ p2
        plots.plotv3(p1r, p2r)
    plt.title(f"(d) Vectors rotated about {name}-axis (0°, 30°, 60°)")
    plt.savefig(f"Q1fig/Q1_d_{name}.png", dpi=300)
    plt.close()

#(e) Homogeneous vectors
p1h = np.array([[0], [0], [0], [1]])
p2h = np.array([[1], [1], [1], [1]])
for name, Rfunc in axes:
    for a in angles:
        T = np.eye(4)
        T[:3, :3] = Rfunc(a)
        p1r = T @ p1h
        p2r = T @ p2h
        plots.plotv4(p1r, p2r)
    plt.title(f"(e) Homogeneous vectors rotated about {name}-axis (0°, 30°, 60°)")
    plt.savefig(f"Q1fig/Q1_e_{name}.png", dpi=300)
    plt.close()

# (f) 
for name, Rfunc in axes:
    for a in angles:
        R = Rfunc(a)
        T = np.eye(4)
        T[:3, :3] = R
        plots.plotf(T)
    plt.title(f"(f) Frames rotated about {name}-axis (0°, 30°, 60°)")
    plt.savefig(f"Q1fig/Q1_f_{name}.png", dpi=300)
    plt.close()


# %%
# Question 3
angles = np.deg2rad([0, 45, 30])
R = EULERXYZ(angles)
ax = plots.plotr(np.eye(3))    
plots.plotr(R, idx=1, ax=ax)
plt.title("Euler XYZ Rotation (0°, 45°, 30°)")
plt.savefig("fig/Q3_rotation1.png")
plt.close()
angles = np.deg2rad([0, 30, 45])
R = EULERXYZ(angles)
ax = plots.plotr(np.eye(3))    
plots.plotr(R, idx=1, ax=ax)
plt.title("Euler XYZ Rotation (0°, 30°, 45°)")
plt.savefig("fig/Q3_rotation2.png")
plt.close()

# %%

# Question 4
# (a) Periodicity Test
angles = np.deg2rad([0, 90, 0])
R1 = EULERXYZ(angles)
R2 = EULERXYZ([angles[0] + 2*np.pi, angles[1], angles[2]])
plots.plotr(R1)
plots.plotr(R2)
plt.title("(a) Periodicity: R([a,b,c]) = R([a+2π,b,c])")
plt.savefig("Q4_a_periodicity.png", dpi=300)
plt.close()
diff_a = np.round(np.linalg.norm(R1 - R2), 12)
print("Q4(a) diff =", diff_a)
# (b) Gimbal Lock Case (sin β ≈ 0)
angles_gimbal = np.deg2rad([45, 0, 30])
R_gimbal = EULERXYZ(angles_gimbal)
_ = EULERXYZINV(R_gimbal) 
# (c)
angles_test = np.deg2rad([4*180, 0, 0])  # 4π rad = 720°
R = EULERXYZ(angles_test)
inv_angles = EULERXYZINV(R)
print("Q4(c) Non-unique inverse test")
print("Input angles:", angles_test)
print("Recovered angles:", inv_angles)
#(d)
angles = np.deg2rad([0, 90, 0])
R = EULERXYZ(angles)
inv_angles = EULERXYZINV(R)
R_back = EULERXYZ(inv_angles)
ax = plots.plotr(R)
plots.plotr(R_back, idx=1, ax=ax)
plt.title("(d) R = EULERXYZ(EULERXYZINV(R))")
plt.savefig("fig/Q4_d_consistency.png", dpi=300)
plt.close()
diff_d = np.round(np.linalg.norm(R - R_back), 12)
print("Q4(d) diff =", diff_d)

# %%
# Question 5
from SKEW3 import SKEW3
x = np.array([[1], [2], [3]])
y = np.array([[4], [5], [6]])
diff = np.linalg.norm(SKEW3(x) @ y - np.cross(x.flatten(), y.flatten()).reshape(3,1))
print("Q5 diff =", np.round(diff, 12))

# np.cross
y_cross = np.cross(x.flatten(), y.flatten()).reshape(3,1)
# Skew
y_skew = SKEW3(x) @ y

# 
plots.plotv3(np.zeros((3,1)), y)
plots.plotv3(np.zeros((3,1)), y_cross*1.01,'r') 
plots.plotv3(np.zeros((3,1)), y_skew,'g') 

plt.title("Q5: SKEW3(x) validation — y, cross(x,y), and SKEW3(x)@y")
plt.savefig("fig/Q5_SKEW3_visual.png", dpi=300)
plt.close()

# Question 6 function can be proved in Question 7
# %%
# Question 7
# (a) 
axes = [np.array([np.pi/4, 0, 0]),
        np.array([0, np.pi/4, 0]),
        np.array([0, 0, np.pi/4])]
names = ['x', 'y', 'z']
vector = np.array([1, 0, 0])
for i, x in enumerate(axes):
    R = EXPCR(x)
    ax = plots.plotr(np.eye(3))
    plots.plotr(R, idx=1, ax=ax)
    plt.title(f"(a) Rotation about {names[i]}-axis by 45°")
    plt.savefig(f"Q7_a_{names[i]}axis.png", dpi=300)
    plt.close()
    v_rot = R @ vector
    plots.plotv3(np.zeros(3), vector)
    plots.plotv3(np.zeros(3), v_rot,'r')
    plt.title(f"(b) 3 vectors rotated about {names[i]}-axis (45°)")
    plt.savefig(f"Q7_b_{names[i]}axis_vectors.png", dpi=300)
    plt.close()

# ==============================================================
# %%
# Question 8
from SKEW6 import SKEW6
xi = np.array([1, 2, 3, 4, 5, 6])
Xi = SKEW6(xi)
print("Q8:")
print(Xi)

# ==============================================================
# Question 10
twists = [
    np.array([np.pi/4, 0, 0, 0.5, 0, 0]),
    np.array([0, np.pi/4, 0, 0, 0.5, 0]), 
    np.array([0, 0, np.pi/4, 0, 0, 0.5])  
]
names = ['x', 'y', 'z']

for i, xi in enumerate(twists):
    T = EXPCF(xi)
    plots.plotf(np.eye(4))
    plots.plotf(T)

    plt.title(f"(a) Transformation about {names[i]}-axis (45°, 0.5 translation)")
    plt.savefig(f"Q10_a_{names[i]}axis.png", dpi=300)
    plt.close()


# (b)
vector = np.array([1, 1, 0, 1])
origin = np.array([0, 0, 0, 1])

for i, xi in enumerate(twists):
    T = EXPCF(xi)
    v_trans = T @ vector
    origin_trans = T @ origin
    plots.plotv3(origin[:3], vector[:3])
    plots.plotv3(origin_trans[:3], v_trans[:3], 'r')
    plt.title(f"(b) Vector transformed about {names[i]}-axis (45°, 0.5 translation)")
    plt.savefig(f"Q10_b_{names[i]}axis_vectors.png", dpi=300)
    plt.close()

# ==============================================================
# Question 11
from FINV import FINV
# construct a transformation
xi = np.array([0, 0, np.pi/2, 1, 0, 0])
T = EXPCF(xi)
T_inv = FINV(T)
# check
I_check = T @ T_inv
print("Q11: \nT * T_inv =\n", np.round(I_check, 3))


# %%
