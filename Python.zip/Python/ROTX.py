import numpy as np

def ROTX(theta):
    """Rotation matrix about X-axis by theta radians."""
    return np.array([
        [1, 0, 0],
        [0, np.cos(theta), -np.sin(theta)],
        [0, np.sin(theta), np.cos(theta)]
    ])
