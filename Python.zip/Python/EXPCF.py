import numpy as np
from SKEW3 import SKEW3
from EXPCR import EXPCR
import numpy as np
from SKEW3 import SKEW3
from EXPCR import EXPCR

def EXPCF(xi):
    """
    Compute 4x4 rigid-body transformation matrix T = exp([ξ]_x)
    using the twist vector ξ = [w, v]^T.

    Input:
        xi : 6x1 vector [w1, w2, w3, v1, v2, v3]^T
    Output:
        T  : 4x4 homogeneous transformation matrix
    """
    xi = np.asarray(xi).reshape(6,)
    w = xi[0:3]
    v = xi[3:6]
    theta = np.linalg.norm(w)
    I = np.eye(3)

    # --- Rotation part ---
    R = EXPCR(w)
    # --- Translation part ---
    if theta < 1e-8:
        # when rotation is very small, translation ≈ v
        p = v
    else:
        w_hat = SKEW3(w / theta)
        G = (I + (1 - np.cos(theta)) / (theta**2) * w_hat +
             (theta - np.sin(theta)) / (theta**3) * (w_hat @ w_hat))
        p = G @ v

    T = np.eye(4)
    T[0:3, 0:3] = R
    T[0:3, 3] = p
    return T
