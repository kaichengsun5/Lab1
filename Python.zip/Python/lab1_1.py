import time
from ur_interface import UrInterface

ur5e = UrInterface()
time.sleep(3)  

# ur5e.activate_pos_control()
# time.sleep(1)

theta_0 = ur5e.home
theta_1 = [0.5, -0.8, 0.6, -1.0, 0.4, 0.0]
theta_2 = [1.0, -1.0, 0.0, 0.0, 0.0, 0.0]
theta_3 = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

try:
    ur5e.move_joints(theta_0, 10); time.sleep(10)
    ur5e.move_joints(theta_1, 10); time.sleep(10)
    ur5e.move_joints(theta_2, 10); time.sleep(10)
    theta = ur5e.get_current_joints()
    print("Current joints:", theta)
    ur5e.move_joints(theta_3, 10); time.sleep(10)
    print("Finished successfully.")

except Exception as e:
    print("Something went wrong:", e)
