# plots.py
# Copyright (c) 2025 Annie Huang, Jiacheng Li. All rights reserved.

import numpy as np
import matplotlib.pyplot as plt

def get_3d_axes(fig=None, clear=False):
    """
    Get or create a 3D axes in the given figure.
    If clear=True, clears the figure first and creates a fresh 3D axes.
    If clear=False, reuses an existing 3D axes if one exists; otherwise creates a new one.
    Returns (fig, ax).
    """
    if fig is None:
        fig = plt.gcf()
    if clear:
        fig.clf()
    else:
        # reuse existing 3D axes if present
        for existing_ax in fig.get_axes():
            if hasattr(existing_ax, 'zaxis'):
                return fig, existing_ax
    # create a new 3D axes
    ax = fig.add_subplot(111, projection='3d', aspect="auto")
    ax.view_init(elev=30, azim=-60)
    ax.set_xlabel(r'$X_0$')
    ax.set_ylabel(r'$Y_0$')
    ax.set_zlabel(r'$Z_0$')
    return fig, ax


def extract_color(args, default=(0, 0, 0)):
    """
    Helper to extract a matplotlib color spec from args.
    """
    return args[0] if args else default


# ---- plotp3: single 3-vector as point ----
def plotp3(p0, *args, ax=None):
    """
    Function accepts a single 3x1 vector and plots the vector as a point,
    with an optional argument for coloring.

    Parameters:
    p0: a 3x1 numpy array
    args[0]: (optional) a color specification, either a matplotlib color string
             (e.g. 'r') or a RGB tuple of values between 0 and 1

    Usage examples:  
    plotp3(np.array([1, 0, 0]))
    plotp3(np.array([1, 0, 0]), 'r')
    plotp3(np.array([1, 0, 0]), (np.random.rand(), np.random.rand(), np.random.rand()))
    """

    p0 = np.array(p0).flatten()
    
    # Check dimensions
    if p0.shape != (3,):
        raise ValueError('plotp3 requires a 3x1 vector argument. Check your dimensions.')
    
    # Get current axes or create new ones
    if ax is None:
        _, ax = get_3d_axes(clear=False)
    
    c = extract_color(args)
    ax.scatter([p0[0]], [p0[1]], [p0[2]], color=c)
    ax.grid(True)
    ax.set_box_aspect([1,1,1])
    return ax


# ---- plotp4: homogeneous 4-vector as point ----
def plotp4(p0, *args, ax=None):
    """
    Function accepts a single 4x1 vector (i.e. a position vector in
    homogeneous representation) and plots the vector as a point, with an
    optional argument for coloring.

    Parameters:
    p0: a 4x1 numpy array
    args[0]: (optional) a color specification, either a matplotlib color string
             (e.g. 'r') or a RGB tuple of values between 0 and 1

    Usage examples:
    plotp4(np.array([1, 0, 0, 1]))
    plotp4(np.array([1, 0, 0, 1]), 'r')
    plotp4(np.array([1, 0, 0, 1]), (np.random.rand(), np.random.rand(), np.random.rand()))
    """

    p0 = np.array(p0).flatten()

     # Check dimensions
    if p0.shape != (4,):
        raise ValueError('plotp4 requires a 4x1 vector argument. Check your dimensions.')
    
    X = p0[:3] / p0[3]

    # Get current axes or create new ones
    if ax is None:
        _, ax = get_3d_axes(clear=False)
    
    c = extract_color(args)
    ax.scatter([X[0]], [X[1]], [X[2]], color=c)
    
    ax.grid(True)
    ax.set_box_aspect([1,1,1])
    return ax


# ---- plotr: 3x3 rotation matrix columns as vectors ----
def plotr(m, idx=None, *args, ax=None):
    """
    Function accepts a single 3x3 matrix and plots the columns of the matrix
    as vectors, with an optional argument for labeling.

    Parameters:
    m: a 3x3 rotation matrix
    args[0]: (optional) a scalar index

    Usage examples:
    h = np.eye(3)
    plotr(h)
    plotr(h, 5)
    """

    m = np.array(m)

    # Check dimensions
    if m.shape != (3, 3):
        raise ValueError('PLOTR requires a 3x3 matrix argument. Check your dimensions.')
    
    # Check if it's a valid rotation matrix (determinant should be 1)
    det = np.linalg.det(m)
    if not (0.999 < det < 1.001):
        print(f'Error in PLOTR: the argument is not a rotation. Determinant is {det}, should be 1.0')
        raise ValueError('aborting')
    
    # Get current axes or create new ones
    if ax is None:
        _, ax = get_3d_axes(clear=False)

    colors = ['r', 'g', 'b']
    labels = ['X', 'Y', 'Z']
    zero = np.zeros(3)

    for i in range(3):
        v = m[:, i]
        ax.plot([0, v[0]], [0, v[1]], [0, v[2]], color=colors[i], marker='o')
        # text label at tip
        if idx is not None:
            txt = f"{labels[i].lower()}{idx}"  # 'x1', 'y1', etc.
        else:
            txt = labels[i]
        ax.text(v[0], v[1], v[2], txt)

    ax.grid(True) 
    
    lim = 1.25
    neg_lim = -lim;
    
    ax.set_xlim([neg_lim, lim])
    ax.set_ylim([neg_lim, lim])
    ax.set_zlim([neg_lim, lim])
    ax.set_box_aspect([1,1,1])
    return ax


# ---- plotv3: 3-vector segment ----
def plotv3(X0, X1, *args, ax=None):
    """
    Function accepts two 3x1 vectors and plots their difference as a line
    segment from X0_vec to X1_vec, with an optional argument for coloring.

    Parameters:
    X0_vec: a 3x1 numpy array
    X1_vec: a 3x1 numpy array
    args[0]: (optional) a color specification, either a matplotlib color string
             (e.g. 'r') or a RGB tuple of values between 0 and 1

    Usage examples:
    plotv3(np.array([1, 0, 0]), np.array([0, 1, 0]))
    plotv3(np.array([1, 0, 0]), np.array([0, 1, 0]), 'r')
    plotv3(np.array([1, 0, 0]), np.array([0, 1, 0]), (np.random.rand(), np.random.rand(), np.random.rand()))
    """

    X0 = np.array(X0).flatten()
    X1 = np.array(X1).flatten()
    if X0.shape != (3,) or X1.shape != (3,):
        raise ValueError('PLOTV3 requires two 3x1 vector arguments as start and end. Check your dimensions.')
    
    if ax is None:
        _, ax = get_3d_axes(clear=False)
    
    c = extract_color(args)
    ax.plot([X0[0], X1[0]],
            [X0[1], X1[1]],
            [X0[2], X1[2]],
            color=c, marker='o')
    
    ax.set_box_aspect([1,1,1])
    ax.view_init(elev=20, azim=30)  # 改变3D视角

    return ax


# ---- plotv4: homogeneous 4-vector segment ----
def plotv4(X0, X1, *args, ax=None):
    """
    Function accepts two 4x1 vectors (i.e. two position vectors in
    homogeneous representation) and plots their difference as a line segment
    from X0_vec to X1_vec, with an optional argument for coloring.

    Parameters:
    X0_vec: a 4x1 numpy array
    X1_vec: a 4x1 numpy array
    args[0]: (optional) a color specification, either a matplotlib color string
             (e.g. 'r') or a RGB tuple of values between 0 and 1

    Usage examples: 	
    plotv4(np.array([1, 0, 0, 1]), np.array([0, 1, 0, 1]))
    plotv4(np.array([1, 0, 0, 1]), np.array([0, 1, 0, 1]), 'r')
    plotv4(np.array([1, 0, 0, 1]), np.array([0, 1, 0, 1]), (np.random.rand(), np.random.rand(), np.random.rand()))
    """

    # Check argument dimensions
    X0 = np.array(X0).flatten()
    X1 = np.array(X1).flatten()
    if X0.shape != (4,) or X1.shape != (4,):
        raise ValueError('PLOTV4 requires two 4x1 vector arguments as start and end. Check your dimensions.')
    
    # convert to Euclidean
    X0e = X0[:3] / X0[3]
    X1e = X1[:3] / X1[3]
    
    # Get current axes or create new ones
    if ax is None:
        _, ax = get_3d_axes(clear=False)

    c = extract_color(args)
    ax.plot([X0e[0], X1e[0]],
            [X0e[1], X1e[1]],
            [X0e[2], X1e[2]],
            color=c, marker='o')
    
    ax.set_box_aspect([1,1,1])
    return ax


# ---- plotf: 4x4 frame with optional label/color ----
def plotf(m, *args, ax=None):
    """
    Function accepts a single 4x4 matrix and plots the frame, with optional
    arguments for labeling

    Parameters:
    m: a 4x4 numpy array
    args[0]: (optional) a scalar index
     
    Usage examples:
    h = np.eye(4)
    plotf(h)
    plotf(h, 1)
    """

    # Check argument dimensions
    m = np.array(m)
    if m.shape != (4, 4):
        raise ValueError('plotf requires a 4x4 homogeneous transform')
    
    R = m[:3, :3]
    t = m[:3, 3]

    # Check if it's a valid rotation matrix (determinant should be 1)
    det = np.linalg.det(R)
    if not (0.999 < det < 1.001):
        print(f'Error in PLOTF: the argument is not a rotation. Determinant is {det}, should be 1.0')
        raise ValueError('aborting')
    
    # Get current axes or create new ones
    if ax is None:
        _, ax = get_3d_axes(clear=False)

    colors = ['r', 'g', 'b']
    # Parse optional arguments
    if len(args) == 0:
        idx = None
    elif len(args) == 1:
        idx = args[0]

    labels = ['x', 'y', 'z']

    for i in range(3):
        v = R[:, i]
        ax.plot([t[0], t[0]+v[0]],
                [t[1], t[1]+v[1]],
                [t[2], t[2]+v[2]],
                color=colors[i], marker='o')
        if idx is not None:
            txt = f"{labels[i]}{idx}"
        else:
            txt = labels[i].upper()
        ax.text(t[0] + v[0], t[1] + v[1], t[2] + v[2], txt)
    
    ax.grid(True) 

    # Get the limits of each axis
    xlim = ax.get_xlim3d()
    ylim = ax.get_ylim3d()
    zlim = ax.get_zlim3d()

    # Calculate the range of data for each dimension
    xrange = abs(xlim[1] - xlim[0])
    yrange = abs(ylim[1] - ylim[0])
    zrange = abs(zlim[1] - zlim[0])
    ax.set_box_aspect((xrange, yrange, zrange))
    return ax
