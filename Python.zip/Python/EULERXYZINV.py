import numpy as np

def EULERXYZINV(R):

    # β = atan2( sqrt(r31² + r32²), r33 )
    beta = np.arctan2(np.sqrt(R[2,0]**2 + R[2,1]**2), R[2,2])
    s_beta = np.sin(beta)

    if abs(s_beta) < 1e-6:
        print("Warning: Gimbal lock condition detected (sinβ≈0).")
        # handle gracefully
        alpha = 0.0
        gamma = np.arctan2(-R[0,1], R[0,0])
    else:
        # α = atan2(r23/sβ, r13/sβ)
        alpha = np.arctan2(R[1,2]/s_beta, R[0,2]/s_beta)
        # γ = atan2(r32/sβ, -r31/sβ)
        gamma = np.arctan2(R[2,1]/s_beta, -R[2,0]/s_beta)

    return np.array([alpha, beta, gamma])
